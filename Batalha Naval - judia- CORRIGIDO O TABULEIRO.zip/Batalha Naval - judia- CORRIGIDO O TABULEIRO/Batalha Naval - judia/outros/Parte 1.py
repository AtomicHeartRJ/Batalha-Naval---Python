
def get_shot(palpite):
    
    ok = "n" #enquanto o usuário ainda não tiver dado nenhum tiro.
    while ok == "n": 
        try: #Para verificar se o tiro contabilizou no tabuleiro.
            tiro = int(input("Por favor, dê uma entrada: "))
            if tiro < 0 or tiro > 99:
                print("Entrada incorreta, tente novamente.")
            
            elif tiro in palpite:
                print("Entrada incorreta, tente novamente.")
            
            else:
                ok = "s"
                break
        except:
            print("Por favor, insira novamente. ")
    return tiro


def mostrar_tabuleiro(hit,miss,afundou):
    print("-"* 30)
    print("         Batalha Naval       ")
    print("-"* 30)
    print()

    print("    0  1  2  3  4  5  6  7  8  9 ")
    
    contador = 0 #Para poder ir até a posição 999
    for x in range(10): # gera as linhas
        linha = "" 
        for y in range(10):
            ch = " _ " #caracter
            if contador in hit:
                ch = " o "
            elif contador in miss:
                ch = " x "
            elif contador in afundou:
                ch = " 0 "

            linha = linha + ch
            contador  += 1
        print(x,"",linha) # alinha as linhas


def verificar_tiro(barco1,barco2,hit,miss,afundou,tiro):
    
    if tiro in barco1:
        barco1.remove(tiro)
        if len(barco1) > 0:
            hit.append(tiro)
        else:
            afundou.append(tiro)
    elif tiro in barco2:
        barco2.remove(tiro)
        if len(barco1) > 0:
            hit.append(tiro)
        else:
            afundou.append(tiro)
    else:
        miss.append(tiro)

    return barco1,barco2,hit,miss,afundou



barco1 = [45,46,47]
barco2 = [6,12,26]
hit = [] #se o ataque for nessas posições... apenas um exemplo
miss = []
afundou = []



for i in range(10):
    palpite = hit + miss + afundou #isso aq vai servir para caso o usuario de um palpite já usado
    tiro = get_shot(palpite)
    barco1,barco2, hit , miss, afundou = verificar_tiro(barco1,barco2 ,hit,miss,afundou,tiro)
    mostrar_tabuleiro(hit, miss, afundou)


    if len(barco1) < 1 and len(barco2) < 1:
        print("Você ganhou! ")
        break
print("Acabou. ")