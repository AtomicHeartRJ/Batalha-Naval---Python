from random import randrange



def checar_ok(barco,taken):
    
    for i in range(len(barco)):
        num = barco[i]
        if num in taken:
            barco = [-1]
            break

        if num < 0 or num > 99:
            barco = [-1]
            break
        elif num % 9 == 0 and i < len(barco) -1:
            if barco[i+1] % 10 ==0 :
                barco  = [-1]
                break
    return barco



def checar_barco(b,start,direcao,taken):
    
    barco = []
    if direcao == 1:
        for i in range(b):
            barco.append(start - i*10)
            barco = checar_ok(barco,taken)
    elif direcao == 2:
        for i in range(b):
            barco.append(start + i)
            barco = checar_ok(barco,taken)
    elif direcao == 3:
        for i in range(b):
            barco.append(start + i*10)
            barco = checar_ok(barco,taken)
    elif direcao == 4:
        for i in range(b):
            barco.append(start - i)
            barco = checar_ok(barco,taken)
    return barco



def criar_barcos():

    taken = []
    navio = []
    barcos = [5] #cinco barcos com 4 de tamanho, 3 barcos com 3 de tamanho e 2 barcos com 2 de tamanho
    for b in barcos:
        barco = [-1]
        while barco[0] == -1:
            barco_inicio = randrange(99)
            barco_direcao = randrange(1,4) #barco começa eno quadrado " " e vai subir até o quadrado ""
            print(b,barco_inicio,barco_direcao)
            barco = checar_barco(b,barco_inicio,barco_direcao,taken)
        navio.append(barco)
        taken = taken + barco
        print(navio)
    return navio , taken



def mostrar_tabuleiro(taken):
    print("-"* 30)
    print("         Batalha Naval       ")
    print("-"* 30)
    print()

    print("    0  1  2  3  4  5  6  7  8  9 ")
    
    contador = 0 #Para poder ir até a posição 999
    for x in range(10): # gera as linhas
        linha = "" 
        for y in range(10):
            ch = " _ " #caracter
            if contador in taken:
                ch = " x "
          
            linha = linha + ch
            contador  += 1
        print(x,"",linha) # alinha as linhas
barcos,taken = criar_barcos()
mostrar_tabuleiro(taken)